const express = require('express');
const cookieParser = require('cookie-parser');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.set('view engine', 'pug');

app.use('/static', express.static('public')); 


app.get('/', (req, res) => {
  res.render('calculator'); 
});

app.listen(3000, () => {
  console.log('The application is running on localhost:3000');
});

app.post('/calculate', (req, res) => {
    console.log("Test");
  const weight = parseFloat(req.body.weight);
  const height = parseFloat(req.body.height);
  const bmi = calculateBMI(weight, height);

  res.render('answer', { weight, height, bmi }); 
});



function calculateBMI(weight, height) {
  return (weight / Math.pow(height / 100, 2)).toFixed(2);
}
